#!/usr/bin/env bash
# SkyLauncher Linux universal installer: x64, ARM64, and Linux distributions.
# Picks the portable Java-bundled archive: works without sudo or a preinstalled Java.
set -euo pipefail

REPO='Newguygame/skylauncher'
API="https://api.github.com/repos/$REPO/releases/latest"
RELEASES="https://github.com/$REPO/releases"
WORK=''

say() { printf '%s\n' "$*"; }
fail() { printf 'SkyLauncher Linux installer: %s\n' "$*" >&2; exit 1; }
cleanup() { if [[ -n "$WORK" && -d "$WORK" ]]; then rm -rf -- "$WORK"; fi; }
asset_urls() {
  grep -Eo '"browser_download_url"[[:space:]]*:[[:space:]]*"[^"\\]*"' "$1" |
    sed -E 's/^"browser_download_url"[[:space:]]*:[[:space:]]*"([^"]*)"$/\1/' || true
}
select_linux_asset() {
  local release="$1" arch="$2" url name lower
  while IFS= read -r url; do
    case "$url" in "https://github.com/$REPO/releases/download/"*) ;; *) continue ;; esac
    name="${url##*/}"
    lower="$(printf '%s' "$name" | tr '[:upper:]' '[:lower:]')"
    case "$arch:$lower" in
      arm64:skylauncher*linux*portable*arm64.tar.gz|arm64:skylauncher*linux*portable*aarch64.tar.gz)
        printf '%s\n' "$url"; return 0 ;;
      x86_64:skylauncher*linux*portable*x86_64.tar.gz|x86_64:skylauncher*linux*portable*amd64.tar.gz)
        printf '%s\n' "$url"; return 0 ;;
    esac
  done < <(asset_urls "$release")
  return 1
}
ask() {
  local reply=''
  printf '%s [y/N] ' "$1"
  IFS= read -r reply || true
  case "$reply" in n|N|no|NO|No) return 1 ;; *) return 0 ;; esac
}
linux_cpu() {
  [[ "$(uname -s)" == Linux ]] || fail 'This installer is only for Linux. Use the separate macOS installer on a Mac.'
  CPU="$(uname -m)"
  case "$CPU" in x86_64|amd64) CPU=x86_64 ;; aarch64|arm64) CPU=arm64 ;; *) fail "Unsupported Linux CPU: $CPU" ;; esac
}
fetch_asset() {
  command -v curl >/dev/null || fail 'curl is required.'
  say 'Checking the latest published SkyLauncher GitHub release...'
  curl --fail --location --silent --show-error --retry 2 --connect-timeout 20 --max-time 120 \
    --proto '=https' --proto-redir '=https' \
    -H 'Accept: application/vnd.github+json' -H 'User-Agent: SkyLauncher-Linux-Installer' \
    "$API" -o "$WORK/release.json" || fail "GitHub release lookup failed. See $RELEASES"
  URL="$(select_linux_asset "$WORK/release.json" "$CPU")" || \
    fail "No matching $CPU portable Linux archive is attached to the latest release. See $RELEASES"
  say "Selected: ${URL##*/}"
  if [[ "$CHECK_ONLY" == 1 ]]; then say 'Matching download found; nothing installed.'; return; fi
  say 'Downloading portable Linux package with Java included...'
  curl --fail --location --silent --show-error --retry 2 --connect-timeout 20 --max-time 900 \
    --proto '=https' --proto-redir '=https' "$URL" -o "$WORK/package.tar.gz" || fail 'Download failed.'
  [[ -s "$WORK/package.tar.gz" ]] || fail 'Downloaded archive is empty.'
}
validate_paths() {
  local path
  while IFS= read -r path; do
    case "$path" in /*|../*|*/../*|..|*/..) fail "Unsafe archive path: $path" ;; esac
  done < "$1"
}
install_linux() {
  command -v tar >/dev/null || fail 'tar is required.'
  tar -tzf "$WORK/package.tar.gz" > "$WORK/entries" || fail 'Archive is invalid.'
  validate_paths "$WORK/entries"
  mkdir -p "$WORK/package"
  tar -xzf "$WORK/package.tar.gz" -C "$WORK/package" || fail 'Could not extract package.'
  [[ -f "$WORK/package/SkyLauncher.jar" && -f "$WORK/package/run.sh" && -f "$WORK/package/install.sh" ]] || \
    fail 'Archive is missing SkyLauncher installer files.'
  local desktop='--no-desktop'
  if ask 'Create a desktop shortcut?'; then desktop='--desktop'; fi
  # Existing portable installer installs into ~/.local/share/skylauncher.
  bash "$WORK/package/install.sh" "$desktop" --no-launch || fail 'Installation failed.'
  say 'SkyLauncher installed; look for it in your Applications menu.'
  if ask 'Launch SkyLauncher now?'; then
    bash "${XDG_DATA_HOME:-$HOME/.local/share}/skylauncher/run.sh"
  fi
}
main() {
  CHECK_ONLY=0
  case "${1:-}" in
    '') ;; --check-only) CHECK_ONLY=1 ;;
    --help|-h) say 'Linux x64 / ARM64 automatic installer for CachyOS, Arch, Fedora, Ubuntu and more. Use --check-only to check asset availability.'; return ;;
    *) fail 'Usage: bash Install-SkyLauncher-Linux.sh [--check-only]' ;;
  esac
  linux_cpu
  say "SkyLauncher Linux installer ($CPU)"
  WORK="$(mktemp -d "${TMPDIR:-/tmp}/skylauncher-linux.XXXXXXXX")" || fail 'Cannot create temporary directory.'
  trap cleanup EXIT
  fetch_asset
  if [[ "$CHECK_ONLY" == 0 ]]; then install_linux; fi
}
if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then main "$@"; fi

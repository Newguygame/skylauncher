SkyLauncher — Universal Linux Installer
======================================

ONE Linux installer for BOTH x64/AMD64 and ARM64 (AArch64).
Designed for Linux distributions using glibc, including CachyOS, Arch,
Fedora, Ubuntu, Debian and similar distributions.
This is NOT a copy of the macOS installer.

Instructions:
1. Unzip the archive.
2. Open a terminal in the extracted folder and run:
      bash Install-SkyLauncher-Linux.sh
3. The installer detects your Linux CPU, downloads the matching portable
   .tar.gz with Java included from the latest GitHub Release and installs
   SkyLauncher into ~/.local/share/skylauncher without sudo.
4. An Applications menu entry is created; desktop shortcut and launch are
   optional. Minecraft profiles/config remain in ~/.ghmodlauncher.

Check without installing:
   bash Install-SkyLauncher-Linux.sh --check-only

The latest GitHub release MUST have a suitable .tar.gz asset, such as:
   SkyLauncher-Linux-Portable-x86_64.tar.gz
   SkyLauncher-Linux-Portable-arm64.tar.gz

This doesn't use .deb or .rpm so it's convenient for many distributions.
Alpine and other musl-based distros may require a separate compatible Java.
Nothing is changed if a compatible release asset cannot be found.

Source: https://github.com/Newguygame/skylauncher

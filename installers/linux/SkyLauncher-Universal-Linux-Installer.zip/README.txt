SkyLauncher for Linux

1. Unzip this download.
2. Open a terminal in the folder.
3. Run: bash Install-SkyLauncher-Linux.sh
4. Follow the instructions.

The installer picks the correct version for your computer.
It asks about a desktop shortcut and opening SkyLauncher.
Press Enter for Yes, or type n for No.

Internet is required. Your Minecraft files are kept.

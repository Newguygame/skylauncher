SkyLauncher installer for Linux
===============================

1. Unzip this download.
2. Open a terminal in the folder.
3. Run: bash Install-SkyLauncher-Linux.sh
4. Follow the questions on screen.

The installer chooses the right version for your computer, downloads it,
and installs SkyLauncher. You can also add a desktop shortcut.

You need an internet connection. If no download is available yet,
the installer will tell you.

Your Minecraft worlds, mods, and settings will not be removed.

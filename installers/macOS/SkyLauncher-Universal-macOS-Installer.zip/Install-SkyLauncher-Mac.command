#!/bin/bash
# SkyLauncher macOS universal installer: Intel and Apple Silicon.
# Download location: https://github.com/Newguygame/skylauncher/releases
set -euo pipefail

REPO='Newguygame/skylauncher'
API="https://api.github.com/repos/$REPO/releases/latest"
RELEASES="https://github.com/$REPO/releases"
WORK=''
MOUNTED=''

say() { printf '%s\n' "$*"; }
fail() { printf 'SkyLauncher macOS installer: %s\n' "$*" >&2; exit 1; }
cleanup() {
  if [[ -n "$MOUNTED" ]]; then hdiutil detach -quiet "$MOUNTED" >/dev/null 2>&1 || true; fi
  if [[ -n "$WORK" && -d "$WORK" ]]; then rm -rf -- "$WORK"; fi
}

# GitHub API may return minified JSON. grep -o captures every asset URL
# even if all assets occur on a single line; no jq or Python required.
asset_urls() {
  grep -Eo '"browser_download_url"[[:space:]]*:[[:space:]]*"[^"\\]*"' "$1" |
    sed -E 's/^"browser_download_url"[[:space:]]*:[[:space:]]*"([^"]*)"$/\1/' || true
}

# Select only a matching official GitHub Release asset.
select_mac_asset() {
  local release="$1" arch="$2" url name lower
  while IFS= read -r url; do
    case "$url" in "https://github.com/$REPO/releases/download/"*) ;; *) continue ;; esac
    name="${url##*/}"
    lower="$(printf '%s' "$name" | tr '[:upper:]' '[:lower:]')"
    case "$arch:$lower" in
      arm64:skylauncher*-arm64.dmg|arm64:skylauncher*-aarch64.dmg|arm64:skylauncher*-apple-silicon.dmg|arm64:skylauncher*-applesilicon.dmg)
        printf '%s\n' "$url"; return 0 ;;
      x86_64:skylauncher*-intel.dmg|x86_64:skylauncher*-x86_64.dmg|x86_64:skylauncher*-x64.dmg)
        printf '%s\n' "$url"; return 0 ;;
    esac
  done < <(asset_urls "$release")
  return 1
}

ask() {
  local reply=''
  printf '%s [y/N] ' "$1"
  IFS= read -r reply || true
  case "$reply" in y|Y|yes|YES|Yes) return 0 ;; *) return 1 ;; esac
}

mac_cpu() {
  [[ "$(uname -s)" == Darwin ]] || fail 'This installer is only for macOS. Use the separate Linux installer on Linux.'
  CPU="$(uname -m)"
  case "$CPU" in arm64|aarch64) CPU=arm64 ;; x86_64|amd64) CPU=x86_64 ;; *) fail "Unsupported Mac CPU: $CPU" ;; esac
  # Rosetta Terminal can report x86_64 on a native Apple Silicon Mac.
  if [[ "$CPU" == x86_64 && "$(sysctl -n hw.optional.arm64 2>/dev/null || true)" == 1 ]]; then CPU=arm64; fi
}

fetch_asset() {
  command -v curl >/dev/null || fail 'curl is required.'
  say 'Checking the latest published SkyLauncher GitHub release...'
  curl --fail --location --silent --show-error --retry 2 --connect-timeout 20 --max-time 120 \
    --proto '=https' --proto-redir '=https' \
    -H 'Accept: application/vnd.github+json' -H 'User-Agent: SkyLauncher-Mac-Installer' \
    "$API" -o "$WORK/release.json" || fail "GitHub release lookup failed. See $RELEASES"
  URL="$(select_mac_asset "$WORK/release.json" "$CPU")" || \
    fail "No matching $CPU macOS DMG is attached to the latest release. See $RELEASES"
  say "Selected: ${URL##*/}"
  if [[ "$CHECK_ONLY" == 1 ]]; then say 'Matching download found; nothing installed.'; return; fi
  say 'Downloading macOS installer...'
  curl --fail --location --silent --show-error --retry 2 --connect-timeout 20 --max-time 900 \
    --proto '=https' --proto-redir '=https' "$URL" -o "$WORK/SkyLauncher.dmg" || fail 'DMG download failed.'
  [[ -s "$WORK/SkyLauncher.dmg" ]] || fail 'Downloaded DMG is empty.'
}

install_mac() {
  command -v hdiutil >/dev/null || fail 'macOS hdiutil is missing.'
  command -v ditto >/dev/null || fail 'macOS ditto is missing.'
  mkdir -p "$WORK/mount"
  hdiutil attach -quiet -readonly -nobrowse -mountpoint "$WORK/mount" "$WORK/SkyLauncher.dmg" || fail 'The downloaded DMG could not be opened.'
  MOUNTED="$WORK/mount"
  local app='' apps="$HOME/Applications" target stage backup=''
  app="$(find "$WORK/mount" -type d -name 'SkyLauncher.app' -print | sed -n '1p')"
  [[ -n "$app" ]] || fail 'The DMG has no SkyLauncher.app.'
  mkdir -p "$apps"
  target="$apps/SkyLauncher.app"
  stage="$(mktemp -d "$apps/.SkyLauncher-install-XXXXXXXX")"
  if ! ditto "$app" "$stage/SkyLauncher.app"; then rm -rf -- "$stage"; fail 'Could not copy the app.'; fi
  if [[ -e "$target" || -L "$target" ]]; then
    backup="$apps/.SkyLauncher-backup-$(basename "$WORK").app"
    if ! mv -- "$target" "$backup"; then rm -rf -- "$stage"; fail 'Could not move old installation.'; fi
  fi
  if ! mv -- "$stage/SkyLauncher.app" "$target"; then
    if [[ -n "$backup" ]]; then mv -- "$backup" "$target" || true; fi
    rm -rf -- "$stage"
    fail 'Could not finish app installation.'
  fi
  rmdir "$stage" || true
  if [[ -n "$backup" ]]; then rm -rf -- "$backup"; fi
  say "Installed to $target (no sudo required)."
  if [[ -d "$HOME/Desktop" ]] && ask 'Create a desktop shortcut?'; then
    if [[ -e "$HOME/Desktop/SkyLauncher.app" && ! -L "$HOME/Desktop/SkyLauncher.app" ]]; then
      say 'Desktop already has a SkyLauncher app; not replacing it.'
    else
      ln -sfn "$target" "$HOME/Desktop/SkyLauncher.app"
      say 'Desktop shortcut created.'
    fi
  fi
  if ask 'Launch SkyLauncher now?'; then
    open "$target" || say 'macOS blocked the app. Check System Settings > Privacy & Security.'
  fi
}

main() {
  CHECK_ONLY=0
  case "${1:-}" in
    '') ;; --check-only) CHECK_ONLY=1 ;;
    --help|-h) say 'macOS Intel / Apple Silicon automatic installer. Use --check-only to check asset availability.'; return ;;
    *) fail 'Usage: bash Install-SkyLauncher-Mac.command [--check-only]' ;;
  esac
  mac_cpu
  say "SkyLauncher macOS installer ($CPU)"
  WORK="$(mktemp -d "${TMPDIR:-/tmp}/skylauncher-mac.XXXXXXXX")" || fail 'Cannot create temp directory.'
  trap cleanup EXIT
  fetch_asset
  if [[ "$CHECK_ONLY" == 0 ]]; then install_mac; fi
}

if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then main "$@"; fi

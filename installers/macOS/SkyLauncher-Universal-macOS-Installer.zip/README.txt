SkyLauncher installer for Mac
============================

1. Unzip this download.
2. Double-click Install-SkyLauncher-Mac.command.
3. Follow the questions on screen.

If double-clicking does not work, open Terminal in the same folder and run:
  bash Install-SkyLauncher-Mac.command

The installer chooses the right version for your Mac, downloads it, and
installs SkyLauncher. You can also add a desktop shortcut.

You need an internet connection. If no download is available yet,
the installer will tell you.

Your Minecraft worlds, mods, and settings will not be removed.

SkyLauncher — Universal macOS Installer
======================================

ONE installer for BOTH Intel Macs and Apple Silicon Macs (M1/M2/M3/M4/etc.).
This is NOT a copy of the Linux installer.

Instructions:
1. Unzip the archive.
2. Double-click Install-SkyLauncher-Mac.command to run it in Terminal.
   If double-click is blocked, launch Terminal and run:
      bash Install-SkyLauncher-Mac.command
3. The installer detects your Mac CPU, downloads the matching .dmg from the
   newest published SkyLauncher GitHub Release, and installs SkyLauncher.app
   into ~/Applications. No sudo or separate Java installation required.
4. Optionally create a desktop shortcut and open the installed app.

Check without installing:
   bash Install-SkyLauncher-Mac.command --check-only

The latest GitHub release MUST have an architecture-specific .dmg asset, such as:
   SkyLauncher-3.1.1-intel.dmg
   SkyLauncher-3.1.1-arm64.dmg

It will show an error if assets aren't published; it won't silently select
an incompatible version. This installer doesn't modify ~/.ghmodlauncher.
Unsigned macOS apps may be blocked by Apple's Gatekeeper security features.

Source: https://github.com/Newguygame/skylauncher

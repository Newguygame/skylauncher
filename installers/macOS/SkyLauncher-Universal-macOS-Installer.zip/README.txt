SkyLauncher for Mac

1. Unzip this download.
2. Double-click Install-SkyLauncher-Mac.command.
3. Follow the instructions.

The installer picks the right version for your Mac.
It asks about a desktop shortcut and opening SkyLauncher.
Press Enter for Yes, or type n for No.

Internet is required. Your Minecraft files are kept.
